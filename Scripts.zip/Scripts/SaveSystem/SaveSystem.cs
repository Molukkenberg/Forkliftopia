using UnityEngine;
using System.IO;

public class SaveSystem : MonoBehaviour
{
    void Start()
    {
        
    }

  

}

public class SaveObject
{

}
