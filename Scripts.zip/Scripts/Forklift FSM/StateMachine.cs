using System;
using System.Collections;
using System.Collections.Generic;
using Unity.IO.LowLevel.Unsafe;
using UnityEngine;

public interface IState
{
    public void Enter()
    {
        // code that runs when we first enter the state
    }
    public void Update()
    {
        // per-frame logic, include condition to transition to a new state
    }
    public void Exit()
    {
        // code that runs when we exit the state
    }
}


[Serializable]
public class StateMachine //: MonoBehaviour // Erbe von MonoBehaviour war in der Vorlage nicht dabei
{
    public IState CurrentState { get; private set; }

    public PickState pickState;
    //public WalkState walkState;
    //public JumpState jumpState;
    //public IdleState idleState;

    public StateMachine()
    {
        this.pickState = new PickState();
    }

    private void Awake()                // Awake Methode war in der Vorlage auch nicht dabei
    {
        //pickState = gameObject.AddComponent<PickState>();
    }

    public void Initialize(IState startingState)
    {
        CurrentState = startingState;
        startingState.Enter();
    }
    public void TransitionTo(IState nextState)
    {
        CurrentState.Exit();
        CurrentState = nextState;
        nextState.Enter();
    }
    public void Update()
    {
        if (CurrentState != null)
        {
            CurrentState.Update();
        }
    }
}