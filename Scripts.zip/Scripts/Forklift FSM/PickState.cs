using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PickState : IState // Macht Probleme :(
{
    private PickGoods pickGoods;
    private NavMeshAgent navMeshAgent;

    public void Entry()
    {
        //pickGoods = GetComponent<PickGoods>();
        //navMeshAgent = GetComponent<NavMeshAgent>();
        
    }
    public void Update()
    {
        if (pickGoods.GetFirstObject() != null)
        {
            // Die Methode k�nnte ein Problem verursachen
            var goodToPick = pickGoods.GetFirstObject();

            navMeshAgent.destination = goodToPick.transform.position;

        //    if (Vector3.Distance(transform.position, navMeshAgent.destination) < 3)
            {
          //      transform.LookAt(goodToPick.transform);
            //    goodToPick.transform.SetParent(gameObject.transform);
                pickGoods.ClearFirstPickableSlot();

                // 
                WorkerParent.Instance.SetStoredGoods(WorkerParent.Instance.GetStoredGoods() - 1);
                
                // Hier den Exit
                //putPickAway = true;
                //picking = false;
            }
        }
    }
    public void Exit()
    {

    }
}
